<script src="<?= base_url() ?>/assets/plugins/apex/apexcharts.min.js"></script>
<script src="<?= base_url() ?>/assets/js/dashboard/dash_1.js"></script>
