<link href="<?= base_url() ?>/assets/css/scrollspyNav.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>/assets/css/forms/theme-checkbox-radio.css">
<link href="<?= base_url() ?>/assets/css/tables/table-basic.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>/assets/css/forms/switches.css"/>

<link rel="stylesheet" type="text/css" href="<?= base_url() ?>/assets/plugins/table/datatable/datatables.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>/assets/plugins/table/datatable/dt-global_style.css">
