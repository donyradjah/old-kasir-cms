<link href="<?= base_url() ?>/assets/plugins/apex/apexcharts.css" rel="stylesheet" type="text/css">
<link href="<?= base_url() ?>/assets/css/dashboard/dash_1.css" rel="stylesheet" type="text/css" />
